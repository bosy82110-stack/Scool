.class public final synthetic Lcom/mostafabudget/expat/MainActivity$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/mostafabudget/expat/MainActivity;

.field public final synthetic f$1:Landroid/net/Uri;


# direct methods
.method public synthetic constructor <init>(Lcom/mostafabudget/expat/MainActivity;Landroid/net/Uri;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/mostafabudget/expat/MainActivity$$ExternalSyntheticLambda3;->f$0:Lcom/mostafabudget/expat/MainActivity;

    iput-object p2, p0, Lcom/mostafabudget/expat/MainActivity$$ExternalSyntheticLambda3;->f$1:Landroid/net/Uri;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    iget-object v0, p0, Lcom/mostafabudget/expat/MainActivity$$ExternalSyntheticLambda3;->f$0:Lcom/mostafabudget/expat/MainActivity;

    iget-object v1, p0, Lcom/mostafabudget/expat/MainActivity$$ExternalSyntheticLambda3;->f$1:Landroid/net/Uri;

    invoke-static {v0, v1}, Lcom/mostafabudget/expat/MainActivity;->$r8$lambda$6vS6_T_OFALQI9mcl_JFIPojLw8(Lcom/mostafabudget/expat/MainActivity;Landroid/net/Uri;)V

    return-void
.end method
