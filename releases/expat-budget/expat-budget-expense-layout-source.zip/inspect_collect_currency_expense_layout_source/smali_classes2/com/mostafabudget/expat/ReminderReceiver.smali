.class public Lcom/mostafabudget/expat/ReminderReceiver;
.super Landroid/content/BroadcastReceiver;
.source "ReminderReceiver.java"


# static fields
.field private static final CHANNEL_ID:Ljava/lang/String; = "budget_reminders"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 11
    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 7
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "intent"    # Landroid/content/Intent;

    .line 16
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/mostafabudget/expat/MainActivity;

    invoke-direct {v0, p1, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 17
    .local v0, "open":Landroid/content/Intent;
    const/high16 v1, 0x8000000

    .line 18
    .local v1, "flags":I
    const/high16 v2, 0x4000000

    or-int/2addr v1, v2

    .line 19
    const/16 v2, 0x3e4

    invoke-static {p1, v2, v0, v1}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v3

    .line 20
    .local v3, "pending":Landroid/app/PendingIntent;
    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v5, 0x1a

    if-lt v4, v5, :cond_0

    .line 21
    new-instance v4, Landroid/app/Notification$Builder;

    const-string v5, "budget_reminders"

    invoke-direct {v4, p1, v5}, Landroid/app/Notification$Builder;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    goto :goto_0

    .line 22
    :cond_0
    new-instance v4, Landroid/app/Notification$Builder;

    invoke-direct {v4, p1}, Landroid/app/Notification$Builder;-><init>(Landroid/content/Context;)V

    :goto_0
    nop

    .line 23
    .local v4, "builder":Landroid/app/Notification$Builder;
    const v5, 0x108003e

    invoke-virtual {v4, v5}, Landroid/app/Notification$Builder;->setSmallIcon(I)Landroid/app/Notification$Builder;

    move-result-object v5

    .line 24
    const-string v6, "\u0645\u064a\u0632\u0627\u0646\u064a\u0629 \u0627\u0644\u0645\u063a\u062a\u0631\u0628"

    invoke-virtual {v5, v6}, Landroid/app/Notification$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v5

    .line 25
    const-string v6, "\u062d\u0627\u0646 \u0648\u0642\u062a \u0625\u0636\u0627\u0641\u0629 \u0645\u0635\u0631\u0648\u0641\u0627\u062a\u0643 \u0627\u0644\u064a\u0648\u0645\u064a\u0629"

    invoke-virtual {v5, v6}, Landroid/app/Notification$Builder;->setContentText(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v5

    .line 26
    invoke-virtual {v5, v3}, Landroid/app/Notification$Builder;->setContentIntent(Landroid/app/PendingIntent;)Landroid/app/Notification$Builder;

    move-result-object v5

    .line 27
    const/4 v6, 0x1

    invoke-virtual {v5, v6}, Landroid/app/Notification$Builder;->setAutoCancel(Z)Landroid/app/Notification$Builder;

    move-result-object v5

    .line 28
    const/4 v6, 0x0

    invoke-virtual {v5, v6}, Landroid/app/Notification$Builder;->setPriority(I)Landroid/app/Notification$Builder;

    .line 29
    const-string v5, "notification"

    invoke-virtual {p1, v5}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/app/NotificationManager;

    .line 30
    .local v5, "manager":Landroid/app/NotificationManager;
    if-eqz v5, :cond_1

    invoke-virtual {v4}, Landroid/app/Notification$Builder;->build()Landroid/app/Notification;

    move-result-object v6

    invoke-virtual {v5, v2, v6}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V

    .line 31
    :cond_1
    return-void
.end method
