.class public final synthetic Lcom/mostafabudget/expat/MainActivity$$ExternalSyntheticLambda4;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/mostafabudget/expat/MainActivity;

.field public final synthetic f$1:Ljava/lang/String;

.field public final synthetic f$2:[B


# direct methods
.method public synthetic constructor <init>(Lcom/mostafabudget/expat/MainActivity;Ljava/lang/String;[B)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/mostafabudget/expat/MainActivity$$ExternalSyntheticLambda4;->f$0:Lcom/mostafabudget/expat/MainActivity;

    iput-object p2, p0, Lcom/mostafabudget/expat/MainActivity$$ExternalSyntheticLambda4;->f$1:Ljava/lang/String;

    iput-object p3, p0, Lcom/mostafabudget/expat/MainActivity$$ExternalSyntheticLambda4;->f$2:[B

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    iget-object v0, p0, Lcom/mostafabudget/expat/MainActivity$$ExternalSyntheticLambda4;->f$0:Lcom/mostafabudget/expat/MainActivity;

    iget-object v1, p0, Lcom/mostafabudget/expat/MainActivity$$ExternalSyntheticLambda4;->f$1:Ljava/lang/String;

    iget-object v2, p0, Lcom/mostafabudget/expat/MainActivity$$ExternalSyntheticLambda4;->f$2:[B

    invoke-static {v0, v1, v2}, Lcom/mostafabudget/expat/MainActivity;->$r8$lambda$VdH0Oq6y0ZIcYNEjF5wzLOy_pZA(Lcom/mostafabudget/expat/MainActivity;Ljava/lang/String;[B)V

    return-void
.end method
