.class public Lcom/mostafabudget/expat/BootReceiver;
.super Landroid/content/BroadcastReceiver;
.source "BootReceiver.java"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 11
    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 17
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "intent"    # Landroid/content/Intent;

    .line 14
    move-object/from16 v1, p1

    const-string v0, "android.intent.action.BOOT_COMPLETED"

    invoke-virtual/range {p2 .. p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    .line 15
    :cond_0
    const-string v0, "reminder"

    const/4 v2, 0x0

    invoke-virtual {v1, v0, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v3

    .line 16
    .local v3, "prefs":Landroid/content/SharedPreferences;
    const-string v0, "enabled"

    invoke-interface {v3, v0, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    if-nez v0, :cond_1

    return-void

    .line 17
    :cond_1
    const-string v0, "time"

    const-string v4, "21:00"

    invoke-interface {v3, v0, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 19
    .local v4, "time":Ljava/lang/String;
    :try_start_0
    const-string v0, ":"

    invoke-virtual {v4, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    .line 20
    .local v0, "parts":[Ljava/lang/String;
    aget-object v5, v0, v2

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    .line 21
    .local v5, "hour":I
    const/4 v6, 0x1

    aget-object v7, v0, v6

    invoke-static {v7}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v7

    .line 22
    .local v7, "minute":I
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v8

    .line 23
    .local v8, "first":Ljava/util/Calendar;
    const/16 v9, 0xb

    invoke-virtual {v8, v9, v5}, Ljava/util/Calendar;->set(II)V

    .line 24
    const/16 v9, 0xc

    invoke-virtual {v8, v9, v7}, Ljava/util/Calendar;->set(II)V

    .line 25
    const/16 v9, 0xd

    invoke-virtual {v8, v9, v2}, Ljava/util/Calendar;->set(II)V

    .line 26
    const/16 v9, 0xe

    invoke-virtual {v8, v9, v2}, Ljava/util/Calendar;->set(II)V

    .line 27
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v2

    invoke-virtual {v8, v2}, Ljava/util/Calendar;->before(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2

    const/4 v2, 0x6

    invoke-virtual {v8, v2, v6}, Ljava/util/Calendar;->add(II)V

    .line 28
    :cond_2
    new-instance v2, Landroid/content/Intent;

    const-class v6, Lcom/mostafabudget/expat/ReminderReceiver;

    invoke-direct {v2, v1, v6}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 29
    .local v2, "reminder":Landroid/content/Intent;
    const-string v6, "com.mostafabudget.expat.DAILY_REMINDER"

    invoke-virtual {v2, v6}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 30
    const/high16 v6, 0x8000000

    .line 31
    .local v6, "flags":I
    const/high16 v9, 0x4000000

    or-int/2addr v6, v9

    .line 32
    const/16 v9, 0x3e3

    invoke-static {v1, v9, v2, v6}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v16

    .line 33
    .local v16, "pending":Landroid/app/PendingIntent;
    const-string v9, "alarm"

    invoke-virtual {v1, v9}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Landroid/app/AlarmManager;

    .line 34
    .local v9, "alarm":Landroid/app/AlarmManager;
    if-eqz v9, :cond_3

    const/4 v11, 0x0

    invoke-virtual {v8}, Ljava/util/Calendar;->getTimeInMillis()J

    move-result-wide v12

    const-wide/32 v14, 0x5265c00

    move-object v10, v9

    invoke-virtual/range {v10 .. v16}, Landroid/app/AlarmManager;->setInexactRepeating(IJJLandroid/app/PendingIntent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 35
    .end local v0    # "parts":[Ljava/lang/String;
    .end local v2    # "reminder":Landroid/content/Intent;
    .end local v5    # "hour":I
    .end local v6    # "flags":I
    .end local v7    # "minute":I
    .end local v8    # "first":Ljava/util/Calendar;
    .end local v9    # "alarm":Landroid/app/AlarmManager;
    .end local v16    # "pending":Landroid/app/PendingIntent;
    :catch_0
    move-exception v0

    :cond_3
    :goto_0
    nop

    .line 36
    return-void
.end method
