.class Lcom/mostafabudget/expat/MainActivity$1;
.super Landroid/hardware/biometrics/BiometricPrompt$AuthenticationCallback;
.source "MainActivity.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/mostafabudget/expat/MainActivity;->startBiometricAuthentication()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/mostafabudget/expat/MainActivity;


# direct methods
.method constructor <init>(Lcom/mostafabudget/expat/MainActivity;)V
    .locals 0
    .param p1, "this$0"    # Lcom/mostafabudget/expat/MainActivity;

    .line 179
    iput-object p1, p0, Lcom/mostafabudget/expat/MainActivity$1;->this$0:Lcom/mostafabudget/expat/MainActivity;

    invoke-direct {p0}, Landroid/hardware/biometrics/BiometricPrompt$AuthenticationCallback;-><init>()V

    return-void
.end method


# virtual methods
.method public onAuthenticationError(ILjava/lang/CharSequence;)V
    .locals 2
    .param p1, "errorCode"    # I
    .param p2, "errString"    # Ljava/lang/CharSequence;

    .line 193
    iget-object v0, p0, Lcom/mostafabudget/expat/MainActivity$1;->this$0:Lcom/mostafabudget/expat/MainActivity;

    const-string v1, "window.biometricResult(false)"

    invoke-static {v0, v1}, Lcom/mostafabudget/expat/MainActivity;->-$$Nest$mcallJavascript(Lcom/mostafabudget/expat/MainActivity;Ljava/lang/String;)V

    .line 194
    return-void
.end method

.method public onAuthenticationFailed()V
    .locals 2

    .line 188
    iget-object v0, p0, Lcom/mostafabudget/expat/MainActivity$1;->this$0:Lcom/mostafabudget/expat/MainActivity;

    const-string v1, "window.biometricResult(false)"

    invoke-static {v0, v1}, Lcom/mostafabudget/expat/MainActivity;->-$$Nest$mcallJavascript(Lcom/mostafabudget/expat/MainActivity;Ljava/lang/String;)V

    .line 189
    return-void
.end method

.method public onAuthenticationSucceeded(Landroid/hardware/biometrics/BiometricPrompt$AuthenticationResult;)V
    .locals 2
    .param p1, "result"    # Landroid/hardware/biometrics/BiometricPrompt$AuthenticationResult;

    .line 183
    iget-object v0, p0, Lcom/mostafabudget/expat/MainActivity$1;->this$0:Lcom/mostafabudget/expat/MainActivity;

    const-string v1, "window.biometricResult(true)"

    invoke-static {v0, v1}, Lcom/mostafabudget/expat/MainActivity;->-$$Nest$mcallJavascript(Lcom/mostafabudget/expat/MainActivity;Ljava/lang/String;)V

    .line 184
    return-void
.end method
