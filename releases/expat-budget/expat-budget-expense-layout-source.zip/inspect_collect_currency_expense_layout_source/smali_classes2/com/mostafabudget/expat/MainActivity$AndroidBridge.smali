.class final Lcom/mostafabudget/expat/MainActivity$AndroidBridge;
.super Ljava/lang/Object;
.source "MainActivity.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/mostafabudget/expat/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "AndroidBridge"
.end annotation


# instance fields
.field final synthetic this$0:Lcom/mostafabudget/expat/MainActivity;


# direct methods
.method public static synthetic $r8$lambda$5n75QEgObNd_ouy9nsu0-bmkOwU(Lcom/mostafabudget/expat/MainActivity$AndroidBridge;)V
    .locals 0

    invoke-direct {p0}, Lcom/mostafabudget/expat/MainActivity$AndroidBridge;->lambda$openBackupPicker$5()V

    return-void
.end method

.method public static synthetic $r8$lambda$8f6-lFHNK4UXAygowqxnTdRzft8(Lcom/mostafabudget/expat/MainActivity$AndroidBridge;)V
    .locals 0

    invoke-direct {p0}, Lcom/mostafabudget/expat/MainActivity$AndroidBridge;->lambda$saveBackup$3()V

    return-void
.end method

.method public static synthetic $r8$lambda$CJ2UtOoAKoxNHuU60Qp3dbvJ9bQ(Lcom/mostafabudget/expat/MainActivity$AndroidBridge;)V
    .locals 0

    invoke-direct {p0}, Lcom/mostafabudget/expat/MainActivity$AndroidBridge;->lambda$savePdf$0()V

    return-void
.end method

.method public static synthetic $r8$lambda$CQ6WPtAlYzxt4tqeWZLRsYCwSQc(Lcom/mostafabudget/expat/MainActivity$AndroidBridge;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lcom/mostafabudget/expat/MainActivity$AndroidBridge;->lambda$saveBackup$4(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public static synthetic $r8$lambda$mOASoNTICNJEi5TA0plGIXrl4nk(Lcom/mostafabudget/expat/MainActivity$AndroidBridge;)V
    .locals 0

    invoke-direct {p0}, Lcom/mostafabudget/expat/MainActivity$AndroidBridge;->lambda$requestNotificationPermission$6()V

    return-void
.end method

.method public static synthetic $r8$lambda$mZFG_JAej-SlloENq-utozV9YW0(Lcom/mostafabudget/expat/MainActivity;)V
    .locals 0

    invoke-static {p0}, Lcom/mostafabudget/expat/MainActivity;->-$$Nest$mstartBiometricAuthentication(Lcom/mostafabudget/expat/MainActivity;)V

    return-void
.end method

.method public static synthetic $r8$lambda$o5rheuf2dRijEhdxfoo9cLyoPsA(Lcom/mostafabudget/expat/MainActivity$AndroidBridge;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lcom/mostafabudget/expat/MainActivity$AndroidBridge;->lambda$savePdf$1(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public static synthetic $r8$lambda$pbNrAr389c8PNZBjPbzeGCrOXBs(Lcom/mostafabudget/expat/MainActivity$AndroidBridge;Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/mostafabudget/expat/MainActivity$AndroidBridge;->lambda$saveBackup$2(Ljava/lang/String;)V

    return-void
.end method

.method private constructor <init>(Lcom/mostafabudget/expat/MainActivity;)V
    .locals 0

    .line 76
    iput-object p1, p0, Lcom/mostafabudget/expat/MainActivity$AndroidBridge;->this$0:Lcom/mostafabudget/expat/MainActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lcom/mostafabudget/expat/MainActivity;Lcom/mostafabudget/expat/MainActivity$AndroidBridge-IA;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/mostafabudget/expat/MainActivity$AndroidBridge;-><init>(Lcom/mostafabudget/expat/MainActivity;)V

    return-void
.end method

.method private synthetic lambda$openBackupPicker$5()V
    .locals 3

    .line 119
    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.intent.action.OPEN_DOCUMENT"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 120
    .local v0, "intent":Landroid/content/Intent;
    const-string v1, "android.intent.category.OPENABLE"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    .line 121
    const-string v1, "application/json"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    .line 122
    iget-object v1, p0, Lcom/mostafabudget/expat/MainActivity$AndroidBridge;->this$0:Lcom/mostafabudget/expat/MainActivity;

    const/16 v2, 0x1008

    invoke-virtual {v1, v0, v2}, Lcom/mostafabudget/expat/MainActivity;->startActivityForResult(Landroid/content/Intent;I)V

    .line 123
    return-void
.end method

.method private synthetic lambda$requestNotificationPermission$6()V
    .locals 4

    .line 139
    iget-object v0, p0, Lcom/mostafabudget/expat/MainActivity$AndroidBridge;->this$0:Lcom/mostafabudget/expat/MainActivity;

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "android.permission.POST_NOTIFICATIONS"

    aput-object v3, v1, v2

    const/16 v2, 0x1007

    invoke-virtual {v0, v1, v2}, Lcom/mostafabudget/expat/MainActivity;->requestPermissions([Ljava/lang/String;I)V

    return-void
.end method

.method private synthetic lambda$saveBackup$2(Ljava/lang/String;)V
    .locals 3
    .param p1, "location"    # Ljava/lang/String;

    .line 107
    iget-object v0, p0, Lcom/mostafabudget/expat/MainActivity$AndroidBridge;->this$0:Lcom/mostafabudget/expat/MainActivity;

    const-string v1, "\u062a\u0645 \u062d\u0641\u0638 \u0627\u0644\u0646\u0633\u062e\u0629 \u0627\u0644\u0627\u062d\u062a\u064a\u0627\u0637\u064a\u0629"

    const/4 v2, 0x1

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 108
    iget-object v0, p0, Lcom/mostafabudget/expat/MainActivity$AndroidBridge;->this$0:Lcom/mostafabudget/expat/MainActivity;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "window.backupSavedFromAndroid(\'"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/mostafabudget/expat/MainActivity$AndroidBridge;->this$0:Lcom/mostafabudget/expat/MainActivity;

    invoke-static {v2, p1}, Lcom/mostafabudget/expat/MainActivity;->-$$Nest$mjsQuote(Lcom/mostafabudget/expat/MainActivity;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "\')"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/mostafabudget/expat/MainActivity;->-$$Nest$mcallJavascript(Lcom/mostafabudget/expat/MainActivity;Ljava/lang/String;)V

    .line 109
    return-void
.end method

.method private synthetic lambda$saveBackup$3()V
    .locals 3

    .line 111
    iget-object v0, p0, Lcom/mostafabudget/expat/MainActivity$AndroidBridge;->this$0:Lcom/mostafabudget/expat/MainActivity;

    const-string v1, "\u062a\u0639\u0630\u0631 \u062d\u0641\u0638 \u0627\u0644\u0646\u0633\u062e\u0629 \u0627\u0644\u0627\u062d\u062a\u064a\u0627\u0637\u064a\u0629"

    const/4 v2, 0x1

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method private synthetic lambda$saveBackup$4(Ljava/lang/String;Ljava/lang/String;)V
    .locals 4
    .param p1, "base64Json"    # Ljava/lang/String;
    .param p2, "fileName"    # Ljava/lang/String;

    .line 104
    const/4 v0, 0x0

    :try_start_0
    invoke-static {p1, v0}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v0

    .line 105
    .local v0, "bytes":[B
    iget-object v1, p0, Lcom/mostafabudget/expat/MainActivity$AndroidBridge;->this$0:Lcom/mostafabudget/expat/MainActivity;

    invoke-static {v1, p2}, Lcom/mostafabudget/expat/MainActivity;->-$$Nest$msanitizeFileName(Lcom/mostafabudget/expat/MainActivity;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "application/json"

    invoke-static {v1, v2, v0, v3}, Lcom/mostafabudget/expat/MainActivity;->-$$Nest$msaveDownloadFile(Lcom/mostafabudget/expat/MainActivity;Ljava/lang/String;[BLjava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 106
    .local v1, "location":Ljava/lang/String;
    iget-object v2, p0, Lcom/mostafabudget/expat/MainActivity$AndroidBridge;->this$0:Lcom/mostafabudget/expat/MainActivity;

    new-instance v3, Lcom/mostafabudget/expat/MainActivity$AndroidBridge$$ExternalSyntheticLambda2;

    invoke-direct {v3, p0, v1}, Lcom/mostafabudget/expat/MainActivity$AndroidBridge$$ExternalSyntheticLambda2;-><init>(Lcom/mostafabudget/expat/MainActivity$AndroidBridge;Ljava/lang/String;)V

    invoke-virtual {v2, v3}, Lcom/mostafabudget/expat/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 112
    .end local v0    # "bytes":[B
    .end local v1    # "location":Ljava/lang/String;
    goto :goto_0

    .line 110
    :catch_0
    move-exception v0

    .line 111
    .local v0, "error":Ljava/lang/Exception;
    iget-object v1, p0, Lcom/mostafabudget/expat/MainActivity$AndroidBridge;->this$0:Lcom/mostafabudget/expat/MainActivity;

    new-instance v2, Lcom/mostafabudget/expat/MainActivity$AndroidBridge$$ExternalSyntheticLambda3;

    invoke-direct {v2, p0}, Lcom/mostafabudget/expat/MainActivity$AndroidBridge$$ExternalSyntheticLambda3;-><init>(Lcom/mostafabudget/expat/MainActivity$AndroidBridge;)V

    invoke-virtual {v1, v2}, Lcom/mostafabudget/expat/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 113
    .end local v0    # "error":Ljava/lang/Exception;
    :goto_0
    return-void
.end method

.method private synthetic lambda$savePdf$0()V
    .locals 4

    .line 88
    iget-object v0, p0, Lcom/mostafabudget/expat/MainActivity$AndroidBridge;->this$0:Lcom/mostafabudget/expat/MainActivity;

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "android.permission.WRITE_EXTERNAL_STORAGE"

    aput-object v3, v1, v2

    const/16 v2, 0x1006

    invoke-virtual {v0, v1, v2}, Lcom/mostafabudget/expat/MainActivity;->requestPermissions([Ljava/lang/String;I)V

    return-void
.end method

.method private synthetic lambda$savePdf$1(Ljava/lang/String;Ljava/lang/String;)V
    .locals 4
    .param p1, "fileName"    # Ljava/lang/String;
    .param p2, "base64Pdf"    # Ljava/lang/String;

    .line 81
    :try_start_0
    iget-object v0, p0, Lcom/mostafabudget/expat/MainActivity$AndroidBridge;->this$0:Lcom/mostafabudget/expat/MainActivity;

    invoke-static {v0, p1}, Lcom/mostafabudget/expat/MainActivity;->-$$Nest$msanitizeFileName(Lcom/mostafabudget/expat/MainActivity;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 82
    .local v0, "safeName":Ljava/lang/String;
    const/4 v1, 0x0

    invoke-static {p2, v1}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v1

    .line 83
    .local v1, "bytes":[B
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x1d

    if-ge v2, v3, :cond_0

    iget-object v2, p0, Lcom/mostafabudget/expat/MainActivity$AndroidBridge;->this$0:Lcom/mostafabudget/expat/MainActivity;

    const-string v3, "android.permission.WRITE_EXTERNAL_STORAGE"

    .line 84
    invoke-virtual {v2, v3}, Lcom/mostafabudget/expat/MainActivity;->checkSelfPermission(Ljava/lang/String;)I

    move-result v2

    if-eqz v2, :cond_0

    .line 86
    iget-object v2, p0, Lcom/mostafabudget/expat/MainActivity$AndroidBridge;->this$0:Lcom/mostafabudget/expat/MainActivity;

    invoke-static {v2, v0}, Lcom/mostafabudget/expat/MainActivity;->-$$Nest$fputpendingPdfName(Lcom/mostafabudget/expat/MainActivity;Ljava/lang/String;)V

    .line 87
    iget-object v2, p0, Lcom/mostafabudget/expat/MainActivity$AndroidBridge;->this$0:Lcom/mostafabudget/expat/MainActivity;

    invoke-static {v2, v1}, Lcom/mostafabudget/expat/MainActivity;->-$$Nest$fputpendingPdfBytes(Lcom/mostafabudget/expat/MainActivity;[B)V

    .line 88
    iget-object v2, p0, Lcom/mostafabudget/expat/MainActivity$AndroidBridge;->this$0:Lcom/mostafabudget/expat/MainActivity;

    new-instance v3, Lcom/mostafabudget/expat/MainActivity$AndroidBridge$$ExternalSyntheticLambda1;

    invoke-direct {v3, p0}, Lcom/mostafabudget/expat/MainActivity$AndroidBridge$$ExternalSyntheticLambda1;-><init>(Lcom/mostafabudget/expat/MainActivity$AndroidBridge;)V

    invoke-virtual {v2, v3}, Lcom/mostafabudget/expat/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 91
    return-void

    .line 93
    :cond_0
    iget-object v2, p0, Lcom/mostafabudget/expat/MainActivity$AndroidBridge;->this$0:Lcom/mostafabudget/expat/MainActivity;

    invoke-static {v2, v0, v1}, Lcom/mostafabudget/expat/MainActivity;->-$$Nest$msavePdfBytes(Lcom/mostafabudget/expat/MainActivity;Ljava/lang/String;[B)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 96
    .end local v0    # "safeName":Ljava/lang/String;
    .end local v1    # "bytes":[B
    goto :goto_0

    .line 94
    :catch_0
    move-exception v0

    .line 95
    .local v0, "error":Ljava/lang/Exception;
    iget-object v1, p0, Lcom/mostafabudget/expat/MainActivity$AndroidBridge;->this$0:Lcom/mostafabudget/expat/MainActivity;

    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/mostafabudget/expat/MainActivity;->-$$Nest$mshowPdfError(Lcom/mostafabudget/expat/MainActivity;Ljava/lang/String;)V

    .line 97
    .end local v0    # "error":Ljava/lang/Exception;
    :goto_0
    return-void
.end method


# virtual methods
.method public openBackupPicker()V
    .locals 2
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 118
    iget-object v0, p0, Lcom/mostafabudget/expat/MainActivity$AndroidBridge;->this$0:Lcom/mostafabudget/expat/MainActivity;

    new-instance v1, Lcom/mostafabudget/expat/MainActivity$AndroidBridge$$ExternalSyntheticLambda4;

    invoke-direct {v1, p0}, Lcom/mostafabudget/expat/MainActivity$AndroidBridge$$ExternalSyntheticLambda4;-><init>(Lcom/mostafabudget/expat/MainActivity$AndroidBridge;)V

    invoke-virtual {v0, v1}, Lcom/mostafabudget/expat/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 124
    return-void
.end method

.method public requestBiometric()V
    .locals 2
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 152
    iget-object v0, p0, Lcom/mostafabudget/expat/MainActivity$AndroidBridge;->this$0:Lcom/mostafabudget/expat/MainActivity;

    new-instance v1, Lcom/mostafabudget/expat/MainActivity$AndroidBridge$$ExternalSyntheticLambda7;

    invoke-direct {v1, v0}, Lcom/mostafabudget/expat/MainActivity$AndroidBridge$$ExternalSyntheticLambda7;-><init>(Lcom/mostafabudget/expat/MainActivity;)V

    invoke-virtual {v0, v1}, Lcom/mostafabudget/expat/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 153
    return-void
.end method

.method public requestNotificationPermission()V
    .locals 2
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 136
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x21

    if-lt v0, v1, :cond_0

    iget-object v0, p0, Lcom/mostafabudget/expat/MainActivity$AndroidBridge;->this$0:Lcom/mostafabudget/expat/MainActivity;

    .line 137
    const-string v1, "android.permission.POST_NOTIFICATIONS"

    invoke-virtual {v0, v1}, Lcom/mostafabudget/expat/MainActivity;->checkSelfPermission(Ljava/lang/String;)I

    move-result v0

    if-eqz v0, :cond_0

    .line 139
    iget-object v0, p0, Lcom/mostafabudget/expat/MainActivity$AndroidBridge;->this$0:Lcom/mostafabudget/expat/MainActivity;

    new-instance v1, Lcom/mostafabudget/expat/MainActivity$AndroidBridge$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0}, Lcom/mostafabudget/expat/MainActivity$AndroidBridge$$ExternalSyntheticLambda0;-><init>(Lcom/mostafabudget/expat/MainActivity$AndroidBridge;)V

    invoke-virtual {v0, v1}, Lcom/mostafabudget/expat/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 142
    :cond_0
    return-void
.end method

.method public saveBackup(Ljava/lang/String;Ljava/lang/String;)V
    .locals 2
    .param p1, "fileName"    # Ljava/lang/String;
    .param p2, "base64Json"    # Ljava/lang/String;
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 102
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/mostafabudget/expat/MainActivity$AndroidBridge$$ExternalSyntheticLambda5;

    invoke-direct {v1, p0, p2, p1}, Lcom/mostafabudget/expat/MainActivity$AndroidBridge$$ExternalSyntheticLambda5;-><init>(Lcom/mostafabudget/expat/MainActivity$AndroidBridge;Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 113
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 114
    return-void
.end method

.method public savePdf(Ljava/lang/String;Ljava/lang/String;)V
    .locals 2
    .param p1, "fileName"    # Ljava/lang/String;
    .param p2, "base64Pdf"    # Ljava/lang/String;
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 79
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/mostafabudget/expat/MainActivity$AndroidBridge$$ExternalSyntheticLambda6;

    invoke-direct {v1, p0, p1, p2}, Lcom/mostafabudget/expat/MainActivity$AndroidBridge$$ExternalSyntheticLambda6;-><init>(Lcom/mostafabudget/expat/MainActivity$AndroidBridge;Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 97
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 98
    return-void
.end method

.method public scheduleReminder(Ljava/lang/String;Z)V
    .locals 3
    .param p1, "time"    # Ljava/lang/String;
    .param p2, "enabled"    # Z
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 128
    iget-object v0, p0, Lcom/mostafabudget/expat/MainActivity$AndroidBridge;->this$0:Lcom/mostafabudget/expat/MainActivity;

    const-string v1, "reminder"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Lcom/mostafabudget/expat/MainActivity;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    .line 129
    const-string v1, "enabled"

    invoke-interface {v0, v1, p2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    if-nez p1, :cond_0

    const-string v1, "21:00"

    goto :goto_0

    :cond_0
    move-object v1, p1

    :goto_0
    const-string v2, "time"

    invoke-interface {v0, v2, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 130
    if-eqz p2, :cond_1

    iget-object v0, p0, Lcom/mostafabudget/expat/MainActivity$AndroidBridge;->this$0:Lcom/mostafabudget/expat/MainActivity;

    invoke-static {v0, p1}, Lcom/mostafabudget/expat/MainActivity;->-$$Nest$mscheduleDailyReminder(Lcom/mostafabudget/expat/MainActivity;Ljava/lang/String;)V

    goto :goto_1

    .line 131
    :cond_1
    iget-object v0, p0, Lcom/mostafabudget/expat/MainActivity$AndroidBridge;->this$0:Lcom/mostafabudget/expat/MainActivity;

    invoke-static {v0}, Lcom/mostafabudget/expat/MainActivity;->-$$Nest$mcancelDailyReminder(Lcom/mostafabudget/expat/MainActivity;)V

    .line 132
    :goto_1
    return-void
.end method

.method public setBiometricEnabled(Z)V
    .locals 3
    .param p1, "enabled"    # Z
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 146
    iget-object v0, p0, Lcom/mostafabudget/expat/MainActivity$AndroidBridge;->this$0:Lcom/mostafabudget/expat/MainActivity;

    const-string v1, "security"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Lcom/mostafabudget/expat/MainActivity;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    .line 147
    const-string v1, "biometric_enabled"

    invoke-interface {v0, v1, p1}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 148
    return-void
.end method
