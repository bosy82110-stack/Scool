.class public final synthetic Lcom/mostafabudget/expat/MainActivity$$ExternalSyntheticLambda6;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public final synthetic f$0:Lcom/mostafabudget/expat/MainActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/mostafabudget/expat/MainActivity;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/mostafabudget/expat/MainActivity$$ExternalSyntheticLambda6;->f$0:Lcom/mostafabudget/expat/MainActivity;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .locals 1

    iget-object v0, p0, Lcom/mostafabudget/expat/MainActivity$$ExternalSyntheticLambda6;->f$0:Lcom/mostafabudget/expat/MainActivity;

    invoke-static {v0, p1, p2}, Lcom/mostafabudget/expat/MainActivity;->$r8$lambda$AaumH82GCvCcXtdvn-8J8F4M-7A(Lcom/mostafabudget/expat/MainActivity;Landroid/content/DialogInterface;I)V

    return-void
.end method
