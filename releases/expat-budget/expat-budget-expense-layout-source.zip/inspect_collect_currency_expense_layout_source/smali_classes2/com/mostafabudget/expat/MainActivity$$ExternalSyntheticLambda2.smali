.class public final synthetic Lcom/mostafabudget/expat/MainActivity$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/mostafabudget/expat/MainActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/mostafabudget/expat/MainActivity;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/mostafabudget/expat/MainActivity$$ExternalSyntheticLambda2;->f$0:Lcom/mostafabudget/expat/MainActivity;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    iget-object v0, p0, Lcom/mostafabudget/expat/MainActivity$$ExternalSyntheticLambda2;->f$0:Lcom/mostafabudget/expat/MainActivity;

    invoke-static {v0}, Lcom/mostafabudget/expat/MainActivity;->$r8$lambda$5GSQdoJ10WWw47WEWn52PXxmyi8(Lcom/mostafabudget/expat/MainActivity;)V

    return-void
.end method
