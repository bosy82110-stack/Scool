.class public Lcom/mostafabudget/expat/MainActivity;
.super Landroid/app/Activity;
.source "MainActivity.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/mostafabudget/expat/MainActivity$AndroidBridge;
    }
.end annotation


# static fields
.field private static final BACKUP_PICKER_REQUEST:I = 0x1008

.field private static final CHANNEL_ID:Ljava/lang/String; = "budget_reminders"

.field private static final NOTIFICATION_REQUEST:I = 0x1007

.field private static final WRITE_STORAGE_REQUEST:I = 0x1006


# instance fields
.field private pendingPdfBytes:[B

.field private pendingPdfName:Ljava/lang/String;

.field private webView:Landroid/webkit/WebView;


# direct methods
.method public static synthetic $r8$lambda$15sdeMPOyB0legSZuOuSBYTplS8(Lcom/mostafabudget/expat/MainActivity;)V
    .locals 0

    invoke-direct {p0}, Lcom/mostafabudget/expat/MainActivity;->lambda$onActivityResult$4()V

    return-void
.end method

.method public static synthetic $r8$lambda$5GSQdoJ10WWw47WEWn52PXxmyi8(Lcom/mostafabudget/expat/MainActivity;)V
    .locals 0

    invoke-direct {p0}, Lcom/mostafabudget/expat/MainActivity;->maybeStartBiometric()V

    return-void
.end method

.method public static synthetic $r8$lambda$5h9xEoCsbOw30kvIw561uHREeYc(Lcom/mostafabudget/expat/MainActivity;Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/mostafabudget/expat/MainActivity;->lambda$savePdfBytes$1(Ljava/lang/String;)V

    return-void
.end method

.method public static synthetic $r8$lambda$6vS6_T_OFALQI9mcl_JFIPojLw8(Lcom/mostafabudget/expat/MainActivity;Landroid/net/Uri;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/mostafabudget/expat/MainActivity;->lambda$onActivityResult$5(Landroid/net/Uri;)V

    return-void
.end method

.method public static synthetic $r8$lambda$AaumH82GCvCcXtdvn-8J8F4M-7A(Lcom/mostafabudget/expat/MainActivity;Landroid/content/DialogInterface;I)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lcom/mostafabudget/expat/MainActivity;->lambda$startBiometricAuthentication$0(Landroid/content/DialogInterface;I)V

    return-void
.end method

.method public static synthetic $r8$lambda$VdH0Oq6y0ZIcYNEjF5wzLOy_pZA(Lcom/mostafabudget/expat/MainActivity;Ljava/lang/String;[B)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lcom/mostafabudget/expat/MainActivity;->lambda$onRequestPermissionsResult$6(Ljava/lang/String;[B)V

    return-void
.end method

.method public static synthetic $r8$lambda$fIexUrlu_u8BNiCl9eS9xwjQ09A(Lcom/mostafabudget/expat/MainActivity;Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/mostafabudget/expat/MainActivity;->lambda$callJavascript$3(Ljava/lang/String;)V

    return-void
.end method

.method public static synthetic $r8$lambda$lK6B6KaGWnLEnk5SKqpsR_oRCGk(Lcom/mostafabudget/expat/MainActivity;Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/mostafabudget/expat/MainActivity;->lambda$showPdfError$2(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$fputpendingPdfBytes(Lcom/mostafabudget/expat/MainActivity;[B)V
    .locals 0

    iput-object p1, p0, Lcom/mostafabudget/expat/MainActivity;->pendingPdfBytes:[B

    return-void
.end method

.method static bridge synthetic -$$Nest$fputpendingPdfName(Lcom/mostafabudget/expat/MainActivity;Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lcom/mostafabudget/expat/MainActivity;->pendingPdfName:Ljava/lang/String;

    return-void
.end method

.method static bridge synthetic -$$Nest$mcallJavascript(Lcom/mostafabudget/expat/MainActivity;Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/mostafabudget/expat/MainActivity;->callJavascript(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mcancelDailyReminder(Lcom/mostafabudget/expat/MainActivity;)V
    .locals 0

    invoke-direct {p0}, Lcom/mostafabudget/expat/MainActivity;->cancelDailyReminder()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mjsQuote(Lcom/mostafabudget/expat/MainActivity;Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    invoke-direct {p0, p1}, Lcom/mostafabudget/expat/MainActivity;->jsQuote(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static bridge synthetic -$$Nest$msanitizeFileName(Lcom/mostafabudget/expat/MainActivity;Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    invoke-direct {p0, p1}, Lcom/mostafabudget/expat/MainActivity;->sanitizeFileName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static bridge synthetic -$$Nest$msaveDownloadFile(Lcom/mostafabudget/expat/MainActivity;Ljava/lang/String;[BLjava/lang/String;)Ljava/lang/String;
    .locals 0

    invoke-direct {p0, p1, p2, p3}, Lcom/mostafabudget/expat/MainActivity;->saveDownloadFile(Ljava/lang/String;[BLjava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static bridge synthetic -$$Nest$msavePdfBytes(Lcom/mostafabudget/expat/MainActivity;Ljava/lang/String;[B)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lcom/mostafabudget/expat/MainActivity;->savePdfBytes(Ljava/lang/String;[B)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mscheduleDailyReminder(Lcom/mostafabudget/expat/MainActivity;Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/mostafabudget/expat/MainActivity;->scheduleDailyReminder(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mshowPdfError(Lcom/mostafabudget/expat/MainActivity;Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/mostafabudget/expat/MainActivity;->showPdfError(Ljava/lang/String;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mstartBiometricAuthentication(Lcom/mostafabudget/expat/MainActivity;)V
    .locals 0

    invoke-direct {p0}, Lcom/mostafabudget/expat/MainActivity;->startBiometricAuthentication()V

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 41
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method

.method private callJavascript(Ljava/lang/String;)V
    .locals 1
    .param p1, "code"    # Ljava/lang/String;

    .line 292
    iget-object v0, p0, Lcom/mostafabudget/expat/MainActivity;->webView:Landroid/webkit/WebView;

    if-eqz v0, :cond_0

    new-instance v0, Lcom/mostafabudget/expat/MainActivity$$ExternalSyntheticLambda5;

    invoke-direct {v0, p0, p1}, Lcom/mostafabudget/expat/MainActivity$$ExternalSyntheticLambda5;-><init>(Lcom/mostafabudget/expat/MainActivity;Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Lcom/mostafabudget/expat/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 293
    :cond_0
    return-void
.end method

.method private cancelDailyReminder()V
    .locals 2

    .line 241
    const-string v0, "alarm"

    invoke-virtual {p0, v0}, Lcom/mostafabudget/expat/MainActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/AlarmManager;

    .line 242
    .local v0, "alarm":Landroid/app/AlarmManager;
    if-eqz v0, :cond_0

    invoke-direct {p0}, Lcom/mostafabudget/expat/MainActivity;->reminderPendingIntent()Landroid/app/PendingIntent;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/app/AlarmManager;->cancel(Landroid/app/PendingIntent;)V

    .line 243
    :cond_0
    return-void
.end method

.method private createNotificationChannel()V
    .locals 4

    .line 202
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1a

    if-lt v0, v1, :cond_0

    .line 203
    new-instance v0, Landroid/app/NotificationChannel;

    const-string v1, "\u062a\u0630\u0643\u064a\u0631 \u0627\u0644\u0645\u0635\u0631\u0648\u0641\u0627\u062a"

    const/4 v2, 0x3

    const-string v3, "budget_reminders"

    invoke-direct {v0, v3, v1, v2}, Landroid/app/NotificationChannel;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;I)V

    .line 205
    .local v0, "channel":Landroid/app/NotificationChannel;
    const-string v1, "\u062a\u0630\u0643\u064a\u0631 \u064a\u0648\u0645\u064a \u0644\u0625\u0636\u0627\u0641\u0629 \u0627\u0644\u0645\u0635\u0631\u0648\u0641\u0627\u062a"

    invoke-virtual {v0, v1}, Landroid/app/NotificationChannel;->setDescription(Ljava/lang/String;)V

    .line 206
    const-class v1, Landroid/app/NotificationManager;

    invoke-virtual {p0, v1}, Lcom/mostafabudget/expat/MainActivity;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/app/NotificationManager;

    .line 207
    .local v1, "manager":Landroid/app/NotificationManager;
    if-eqz v1, :cond_0

    invoke-virtual {v1, v0}, Landroid/app/NotificationManager;->createNotificationChannel(Landroid/app/NotificationChannel;)V

    .line 209
    .end local v0    # "channel":Landroid/app/NotificationChannel;
    .end local v1    # "manager":Landroid/app/NotificationManager;
    :cond_0
    return-void
.end method

.method private jsQuote(Ljava/lang/String;)Ljava/lang/String;
    .locals 3
    .param p1, "value"    # Ljava/lang/String;

    .line 296
    if-nez p1, :cond_0

    const-string v0, ""

    goto :goto_0

    :cond_0
    move-object v0, p1

    :goto_0
    const-string v1, "\\"

    const-string v2, "\\\\"

    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "\'"

    const-string v2, "\\\'"

    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "\n"

    const-string v2, " "

    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private synthetic lambda$callJavascript$3(Ljava/lang/String;)V
    .locals 2
    .param p1, "code"    # Ljava/lang/String;

    .line 292
    iget-object v0, p0, Lcom/mostafabudget/expat/MainActivity;->webView:Landroid/webkit/WebView;

    const/4 v1, 0x0

    invoke-virtual {v0, p1, v1}, Landroid/webkit/WebView;->evaluateJavascript(Ljava/lang/String;Landroid/webkit/ValueCallback;)V

    return-void
.end method

.method private synthetic lambda$onActivityResult$4()V
    .locals 2

    .line 318
    const-string v0, "\u062a\u0639\u0630\u0631 \u0642\u0631\u0627\u0621\u0629 \u0627\u0644\u0646\u0633\u062e\u0629 \u0627\u0644\u0627\u062d\u062a\u064a\u0627\u0637\u064a\u0629"

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method private synthetic lambda$onActivityResult$5(Landroid/net/Uri;)V
    .locals 7
    .param p1, "uri"    # Landroid/net/Uri;

    .line 310
    :try_start_0
    invoke-virtual {p0}, Lcom/mostafabudget/expat/MainActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/ContentResolver;->openInputStream(Landroid/net/Uri;)Ljava/io/InputStream;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 311
    .local v0, "input":Ljava/io/InputStream;
    :try_start_1
    new-instance v1, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v1}, Ljava/io/ByteArrayOutputStream;-><init>()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    .line 312
    .local v1, "output":Ljava/io/ByteArrayOutputStream;
    if-eqz v0, :cond_2

    .line 313
    const/16 v2, 0x2000

    :try_start_2
    new-array v2, v2, [B

    .line 314
    .local v2, "buffer":[B
    :goto_0
    invoke-virtual {v0, v2}, Ljava/io/InputStream;->read([B)I

    move-result v3

    move v4, v3

    .local v4, "read":I
    const/4 v5, -0x1

    if-eq v3, v5, :cond_0

    const/4 v3, 0x0

    invoke-virtual {v1, v2, v3, v4}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    goto :goto_0

    .line 315
    :cond_0
    invoke-virtual {v1}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v3

    const/4 v5, 0x2

    invoke-static {v3, v5}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object v3

    .line 316
    .local v3, "encoded":Ljava/lang/String;
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "window.restoreBackupFromAndroid(\'"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-direct {p0, v3}, Lcom/mostafabudget/expat/MainActivity;->jsQuote(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, "\')"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {p0, v5}, Lcom/mostafabudget/expat/MainActivity;->callJavascript(Ljava/lang/String;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 317
    .end local v2    # "buffer":[B
    .end local v3    # "encoded":Ljava/lang/String;
    .end local v4    # "read":I
    :try_start_3
    invoke-virtual {v1}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    .end local v1    # "output":Ljava/io/ByteArrayOutputStream;
    if-eqz v0, :cond_1

    :try_start_4
    invoke-virtual {v0}, Ljava/io/InputStream;->close()V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    .line 319
    .end local v0    # "input":Ljava/io/InputStream;
    :cond_1
    goto :goto_4

    .line 310
    .restart local v0    # "input":Ljava/io/InputStream;
    .restart local v1    # "output":Ljava/io/ByteArrayOutputStream;
    :catchall_0
    move-exception v2

    goto :goto_1

    .line 312
    :cond_2
    :try_start_5
    new-instance v2, Ljava/lang/Exception;

    const-string v3, "\u062a\u0639\u0630\u0631 \u0641\u062a\u062d \u0627\u0644\u0646\u0633\u062e\u0629"

    invoke-direct {v2, v3}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .end local v0    # "input":Ljava/io/InputStream;
    .end local v1    # "output":Ljava/io/ByteArrayOutputStream;
    .end local p1    # "uri":Landroid/net/Uri;
    throw v2
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    .line 310
    .restart local v0    # "input":Ljava/io/InputStream;
    .restart local v1    # "output":Ljava/io/ByteArrayOutputStream;
    .restart local p1    # "uri":Landroid/net/Uri;
    :goto_1
    :try_start_6
    invoke-virtual {v1}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    goto :goto_2

    :catchall_1
    move-exception v3

    :try_start_7
    invoke-virtual {v2, v3}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .end local v0    # "input":Ljava/io/InputStream;
    .end local p1    # "uri":Landroid/net/Uri;
    :goto_2
    throw v2
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_2

    .end local v1    # "output":Ljava/io/ByteArrayOutputStream;
    .restart local v0    # "input":Ljava/io/InputStream;
    .restart local p1    # "uri":Landroid/net/Uri;
    :catchall_2
    move-exception v1

    if-eqz v0, :cond_3

    :try_start_8
    invoke-virtual {v0}, Ljava/io/InputStream;->close()V
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_3

    goto :goto_3

    :catchall_3
    move-exception v2

    :try_start_9
    invoke-virtual {v1, v2}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .end local p1    # "uri":Landroid/net/Uri;
    :cond_3
    :goto_3
    throw v1
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_0

    .line 317
    .end local v0    # "input":Ljava/io/InputStream;
    .restart local p1    # "uri":Landroid/net/Uri;
    :catch_0
    move-exception v0

    .line 318
    .local v0, "error":Ljava/lang/Exception;
    new-instance v1, Lcom/mostafabudget/expat/MainActivity$$ExternalSyntheticLambda7;

    invoke-direct {v1, p0}, Lcom/mostafabudget/expat/MainActivity$$ExternalSyntheticLambda7;-><init>(Lcom/mostafabudget/expat/MainActivity;)V

    invoke-virtual {p0, v1}, Lcom/mostafabudget/expat/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 320
    .end local v0    # "error":Ljava/lang/Exception;
    :goto_4
    return-void
.end method

.method private synthetic lambda$onRequestPermissionsResult$6(Ljava/lang/String;[B)V
    .locals 2
    .param p1, "name"    # Ljava/lang/String;
    .param p2, "bytes"    # [B

    .line 331
    :try_start_0
    invoke-direct {p0, p1, p2}, Lcom/mostafabudget/expat/MainActivity;->savePdfBytes(Ljava/lang/String;[B)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    .local v0, "error":Ljava/lang/Exception;
    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Lcom/mostafabudget/expat/MainActivity;->showPdfError(Ljava/lang/String;)V

    .end local v0    # "error":Ljava/lang/Exception;
    :goto_0
    return-void
.end method

.method private synthetic lambda$savePdfBytes$1(Ljava/lang/String;)V
    .locals 2
    .param p1, "finalLocation"    # Ljava/lang/String;

    .line 279
    const-string v0, "\u062a\u0645 \u062d\u0641\u0638 \u062a\u0642\u0631\u064a\u0631 \u0627\u0644\u0634\u0647\u0631"

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 280
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "window.pdfSavedFromAndroid(\'"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-direct {p0, p1}, Lcom/mostafabudget/expat/MainActivity;->jsQuote(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\')"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/mostafabudget/expat/MainActivity;->callJavascript(Ljava/lang/String;)V

    .line 281
    return-void
.end method

.method private synthetic lambda$showPdfError$2(Ljava/lang/String;)V
    .locals 2
    .param p1, "message"    # Ljava/lang/String;

    .line 286
    const-string v0, "\u062a\u0639\u0630\u0631 \u062d\u0641\u0638 \u0645\u0644\u0641 PDF"

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 287
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "alert(\'\u062a\u0639\u0630\u0631 \u062d\u0641\u0638 \u0645\u0644\u0641 PDF: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    if-nez p1, :cond_0

    const-string v1, "\u062e\u0637\u0623 \u063a\u064a\u0631 \u0645\u0639\u0631\u0648\u0641"

    goto :goto_0

    :cond_0
    move-object v1, p1

    :goto_0
    invoke-direct {p0, v1}, Lcom/mostafabudget/expat/MainActivity;->jsQuote(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "\')"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/mostafabudget/expat/MainActivity;->callJavascript(Ljava/lang/String;)V

    .line 288
    return-void
.end method

.method private synthetic lambda$startBiometricAuthentication$0(Landroid/content/DialogInterface;I)V
    .locals 1
    .param p1, "dialog"    # Landroid/content/DialogInterface;
    .param p2, "which"    # I

    .line 174
    const-string v0, "window.biometricResult(false)"

    invoke-direct {p0, v0}, Lcom/mostafabudget/expat/MainActivity;->callJavascript(Ljava/lang/String;)V

    return-void
.end method

.method private maybeStartBiometric()V
    .locals 3

    .line 157
    const-string v0, "security"

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Lcom/mostafabudget/expat/MainActivity;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    const-string v2, "biometric_enabled"

    invoke-interface {v0, v2, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 158
    invoke-direct {p0}, Lcom/mostafabudget/expat/MainActivity;->startBiometricAuthentication()V

    .line 160
    :cond_0
    return-void
.end method

.method private reminderPendingIntent()Landroid/app/PendingIntent;
    .locals 3

    .line 233
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/mostafabudget/expat/ReminderReceiver;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 234
    .local v0, "intent":Landroid/content/Intent;
    const-string v1, "com.mostafabudget.expat.DAILY_REMINDER"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 235
    const/high16 v1, 0x8000000

    .line 236
    .local v1, "flags":I
    const/high16 v2, 0x4000000

    or-int/2addr v1, v2

    .line 237
    const/16 v2, 0x3e3

    invoke-static {p0, v2, v0, v1}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v2

    return-object v2
.end method

.method private sanitizeFileName(Ljava/lang/String;)Ljava/lang/String;
    .locals 2
    .param p1, "fileName"    # Ljava/lang/String;

    .line 300
    if-eqz p1, :cond_1

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    .line 301
    :cond_0
    const-string v0, "[\\\\/:*?\"<>|]"

    const-string v1, "_"

    invoke-virtual {p1, v0, v1}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0

    .line 300
    :cond_1
    :goto_0
    const-string v0, "\u0645\u064a\u0632\u0627\u0646\u064a\u0629_\u0627\u0644\u0645\u063a\u062a\u0631\u0628_\u0646\u0633\u062e\u0629.json"

    return-object v0
.end method

.method private saveDownloadFile(Ljava/lang/String;[BLjava/lang/String;)Ljava/lang/String;
    .locals 6
    .param p1, "fileName"    # Ljava/lang/String;
    .param p2, "bytes"    # [B
    .param p3, "mimeType"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 246
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1d

    const-string v2, "\u0627\u0644\u062a\u0646\u0632\u064a\u0644\u0627\u062a/\u0645\u064a\u0632\u0627\u0646\u064a\u0629 \u0627\u0644\u0645\u063a\u062a\u0631\u0628/"

    if-lt v0, v1, :cond_4

    .line 247
    new-instance v0, Landroid/content/ContentValues;

    invoke-direct {v0}, Landroid/content/ContentValues;-><init>()V

    .line 248
    .local v0, "values":Landroid/content/ContentValues;
    const-string v1, "_display_name"

    invoke-virtual {v0, v1, p1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 249
    const-string v1, "mime_type"

    invoke-virtual {v0, v1, p3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 250
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v3, Landroid/os/Environment;->DIRECTORY_DOWNLOADS:Ljava/lang/String;

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, "/\u0645\u064a\u0632\u0627\u0646\u064a\u0629 \u0627\u0644\u0645\u063a\u062a\u0631\u0628"

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v3, "relative_path"

    invoke-virtual {v0, v3, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    .line 251
    const/4 v1, 0x1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const-string v3, "is_pending"

    invoke-virtual {v0, v3, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 252
    invoke-virtual {p0}, Lcom/mostafabudget/expat/MainActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    sget-object v4, Landroid/provider/MediaStore$Downloads;->EXTERNAL_CONTENT_URI:Landroid/net/Uri;

    invoke-virtual {v1, v4, v0}, Landroid/content/ContentResolver;->insert(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;

    move-result-object v1

    .line 253
    .local v1, "uri":Landroid/net/Uri;
    if-eqz v1, :cond_3

    .line 254
    invoke-virtual {p0}, Lcom/mostafabudget/expat/MainActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v4

    invoke-virtual {v4, v1}, Landroid/content/ContentResolver;->openOutputStream(Landroid/net/Uri;)Ljava/io/OutputStream;

    move-result-object v4

    .line 255
    .local v4, "output":Ljava/io/OutputStream;
    if-eqz v4, :cond_1

    .line 256
    :try_start_0
    invoke-virtual {v4, p2}, Ljava/io/OutputStream;->write([B)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 257
    if-eqz v4, :cond_0

    invoke-virtual {v4}, Ljava/io/OutputStream;->close()V

    .line 258
    .end local v4    # "output":Ljava/io/OutputStream;
    :cond_0
    new-instance v4, Landroid/content/ContentValues;

    invoke-direct {v4}, Landroid/content/ContentValues;-><init>()V

    .line 259
    .local v4, "complete":Landroid/content/ContentValues;
    const/4 v5, 0x0

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v4, v3, v5}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    .line 260
    invoke-virtual {p0}, Lcom/mostafabudget/expat/MainActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v3

    const/4 v5, 0x0

    invoke-virtual {v3, v1, v4, v5, v5}, Landroid/content/ContentResolver;->update(Landroid/net/Uri;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I

    .line 261
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    return-object v2

    .line 254
    .local v4, "output":Ljava/io/OutputStream;
    :catchall_0
    move-exception v2

    goto :goto_0

    .line 255
    :cond_1
    :try_start_1
    new-instance v2, Ljava/lang/Exception;

    const-string v3, "\u062a\u0639\u0630\u0631 \u0641\u062a\u062d \u0645\u0644\u0641 \u0627\u0644\u062a\u0646\u0632\u064a\u0644"

    invoke-direct {v2, v3}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .end local v0    # "values":Landroid/content/ContentValues;
    .end local v1    # "uri":Landroid/net/Uri;
    .end local v4    # "output":Ljava/io/OutputStream;
    .end local p1    # "fileName":Ljava/lang/String;
    .end local p2    # "bytes":[B
    .end local p3    # "mimeType":Ljava/lang/String;
    throw v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 254
    .restart local v0    # "values":Landroid/content/ContentValues;
    .restart local v1    # "uri":Landroid/net/Uri;
    .restart local v4    # "output":Ljava/io/OutputStream;
    .restart local p1    # "fileName":Ljava/lang/String;
    .restart local p2    # "bytes":[B
    .restart local p3    # "mimeType":Ljava/lang/String;
    :goto_0
    if-eqz v4, :cond_2

    :try_start_2
    invoke-virtual {v4}, Ljava/io/OutputStream;->close()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    goto :goto_1

    :catchall_1
    move-exception v3

    invoke-virtual {v2, v3}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_2
    :goto_1
    throw v2

    .line 253
    .end local v4    # "output":Ljava/io/OutputStream;
    :cond_3
    new-instance v2, Ljava/lang/Exception;

    const-string v3, "\u062a\u0639\u0630\u0631 \u0625\u0646\u0634\u0627\u0621 \u0645\u0644\u0641 \u0627\u0644\u062a\u0646\u0632\u064a\u0644"

    invoke-direct {v2, v3}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v2

    .line 263
    .end local v0    # "values":Landroid/content/ContentValues;
    .end local v1    # "uri":Landroid/net/Uri;
    :cond_4
    sget-object v0, Landroid/os/Environment;->DIRECTORY_DOWNLOADS:Ljava/lang/String;

    invoke-static {v0}, Landroid/os/Environment;->getExternalStoragePublicDirectory(Ljava/lang/String;)Ljava/io/File;

    move-result-object v0

    .line 264
    .local v0, "downloads":Ljava/io/File;
    new-instance v1, Ljava/io/File;

    const-string v3, "\u0645\u064a\u0632\u0627\u0646\u064a\u0629 \u0627\u0644\u0645\u063a\u062a\u0631\u0628"

    invoke-direct {v1, v0, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 265
    .local v1, "folder":Ljava/io/File;
    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result v3

    if-nez v3, :cond_6

    invoke-virtual {v1}, Ljava/io/File;->mkdirs()Z

    move-result v3

    if-eqz v3, :cond_5

    goto :goto_2

    :cond_5
    new-instance v2, Ljava/lang/Exception;

    const-string v3, "\u062a\u0639\u0630\u0631 \u0625\u0646\u0634\u0627\u0621 \u0645\u062c\u0644\u062f \u0627\u0644\u062a\u0646\u0632\u064a\u0644\u0627\u062a"

    invoke-direct {v2, v3}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v2

    .line 266
    :cond_6
    :goto_2
    new-instance v3, Ljava/io/File;

    invoke-direct {v3, v1, p1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 267
    .local v3, "outputFile":Ljava/io/File;
    new-instance v4, Ljava/io/FileOutputStream;

    invoke-direct {v4, v3}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    .local v4, "output":Ljava/io/FileOutputStream;
    :try_start_3
    invoke-virtual {v4, p2}, Ljava/io/FileOutputStream;->write([B)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    invoke-virtual {v4}, Ljava/io/FileOutputStream;->close()V

    .line 268
    .end local v4    # "output":Ljava/io/FileOutputStream;
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    return-object v2

    .line 267
    .restart local v4    # "output":Ljava/io/FileOutputStream;
    :catchall_2
    move-exception v2

    :try_start_4
    invoke-virtual {v4}, Ljava/io/FileOutputStream;->close()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_3

    goto :goto_3

    :catchall_3
    move-exception v5

    invoke-virtual {v2, v5}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_3
    throw v2
.end method

.method private savePdfBytes(Ljava/lang/String;[B)V
    .locals 3
    .param p1, "fileName"    # Ljava/lang/String;
    .param p2, "bytes"    # [B
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 273
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1d

    if-ge v0, v1, :cond_1

    .line 274
    const-string v0, "android.permission.WRITE_EXTERNAL_STORAGE"

    invoke-virtual {p0, v0}, Lcom/mostafabudget/expat/MainActivity;->checkSelfPermission(Ljava/lang/String;)I

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    .line 275
    :cond_0
    new-instance v0, Ljava/lang/Exception;

    const-string v1, "\u064a\u0644\u0632\u0645 \u0627\u0644\u0633\u0645\u0627\u062d \u0628\u0627\u0644\u062a\u0646\u0632\u064a\u0644\u0627\u062a"

    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0

    .line 276
    :cond_1
    :goto_0
    const-string v0, "application/pdf"

    invoke-direct {p0, p1, p2, v0}, Lcom/mostafabudget/expat/MainActivity;->saveDownloadFile(Ljava/lang/String;[BLjava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 277
    .local v0, "location":Ljava/lang/String;
    move-object v1, v0

    .line 278
    .local v1, "finalLocation":Ljava/lang/String;
    new-instance v2, Lcom/mostafabudget/expat/MainActivity$$ExternalSyntheticLambda1;

    invoke-direct {v2, p0, v1}, Lcom/mostafabudget/expat/MainActivity$$ExternalSyntheticLambda1;-><init>(Lcom/mostafabudget/expat/MainActivity;Ljava/lang/String;)V

    invoke-virtual {p0, v2}, Lcom/mostafabudget/expat/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 282
    return-void
.end method

.method private scheduleDailyReminder(Ljava/lang/String;)V
    .locals 13
    .param p1, "time"    # Ljava/lang/String;

    .line 213
    if-nez p1, :cond_0

    :try_start_0
    const-string v0, "21:00"

    goto :goto_0

    .line 228
    :catch_0
    move-exception v0

    goto :goto_1

    .line 213
    :cond_0
    move-object v0, p1

    :goto_0
    const-string v1, ":"

    invoke-virtual {v0, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    .line 214
    .local v0, "parts":[Ljava/lang/String;
    const/4 v1, 0x0

    aget-object v2, v0, v1

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2

    .line 215
    .local v2, "hour":I
    const/4 v3, 0x1

    aget-object v4, v0, v3

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v4

    .line 216
    .local v4, "minute":I
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v5

    .line 217
    .local v5, "first":Ljava/util/Calendar;
    const/16 v6, 0xb

    invoke-virtual {v5, v6, v2}, Ljava/util/Calendar;->set(II)V

    .line 218
    const/16 v6, 0xc

    invoke-virtual {v5, v6, v4}, Ljava/util/Calendar;->set(II)V

    .line 219
    const/16 v6, 0xd

    invoke-virtual {v5, v6, v1}, Ljava/util/Calendar;->set(II)V

    .line 220
    const/16 v6, 0xe

    invoke-virtual {v5, v6, v1}, Ljava/util/Calendar;->set(II)V

    .line 221
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v1

    invoke-virtual {v5, v1}, Ljava/util/Calendar;->before(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    const/4 v1, 0x6

    invoke-virtual {v5, v1, v3}, Ljava/util/Calendar;->add(II)V

    .line 222
    :cond_1
    const-string v1, "alarm"

    invoke-virtual {p0, v1}, Lcom/mostafabudget/expat/MainActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/app/AlarmManager;

    .line 223
    .local v1, "alarm":Landroid/app/AlarmManager;
    if-eqz v1, :cond_2

    .line 224
    invoke-direct {p0}, Lcom/mostafabudget/expat/MainActivity;->reminderPendingIntent()Landroid/app/PendingIntent;

    move-result-object v12

    .line 225
    .local v12, "pi":Landroid/app/PendingIntent;
    const/4 v7, 0x0

    invoke-virtual {v5}, Ljava/util/Calendar;->getTimeInMillis()J

    move-result-wide v8

    const-wide/32 v10, 0x5265c00

    move-object v6, v1

    invoke-virtual/range {v6 .. v12}, Landroid/app/AlarmManager;->setInexactRepeating(IJJLandroid/app/PendingIntent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 229
    .end local v0    # "parts":[Ljava/lang/String;
    .end local v1    # "alarm":Landroid/app/AlarmManager;
    .end local v2    # "hour":I
    .end local v4    # "minute":I
    .end local v5    # "first":Ljava/util/Calendar;
    .end local v12    # "pi":Landroid/app/PendingIntent;
    :cond_2
    nop

    .line 230
    :goto_1
    return-void
.end method

.method private showPdfError(Ljava/lang/String;)V
    .locals 1
    .param p1, "message"    # Ljava/lang/String;

    .line 285
    new-instance v0, Lcom/mostafabudget/expat/MainActivity$$ExternalSyntheticLambda0;

    invoke-direct {v0, p0, p1}, Lcom/mostafabudget/expat/MainActivity$$ExternalSyntheticLambda0;-><init>(Lcom/mostafabudget/expat/MainActivity;Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Lcom/mostafabudget/expat/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 289
    return-void
.end method

.method private startBiometricAuthentication()V
    .locals 5

    .line 163
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1c

    const-string v2, "window.biometricResult(false)"

    if-ge v0, v1, :cond_0

    .line 164
    invoke-direct {p0, v2}, Lcom/mostafabudget/expat/MainActivity;->callJavascript(Ljava/lang/String;)V

    .line 165
    return-void

    .line 168
    :cond_0
    :try_start_0
    new-instance v0, Landroid/hardware/biometrics/BiometricPrompt$Builder;

    invoke-direct {v0, p0}, Landroid/hardware/biometrics/BiometricPrompt$Builder;-><init>(Landroid/content/Context;)V

    const-string v1, "\u0641\u062a\u062d \u0645\u064a\u0632\u0627\u0646\u064a\u0629 \u0627\u0644\u0645\u063a\u062a\u0631\u0628"

    .line 170
    invoke-virtual {v0, v1}, Landroid/hardware/biometrics/BiometricPrompt$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/hardware/biometrics/BiometricPrompt$Builder;

    move-result-object v0

    const-string v1, "\u062a\u062d\u0642\u0642 \u0645\u0646 \u0647\u0648\u064a\u062a\u0643 \u0644\u0644\u0648\u0635\u0648\u0644 \u0625\u0644\u0649 \u0628\u064a\u0627\u0646\u0627\u062a\u0643 \u0627\u0644\u0645\u0627\u0644\u064a\u0629"

    .line 171
    invoke-virtual {v0, v1}, Landroid/hardware/biometrics/BiometricPrompt$Builder;->setSubtitle(Ljava/lang/CharSequence;)Landroid/hardware/biometrics/BiometricPrompt$Builder;

    move-result-object v0

    const-string v1, "\u0627\u0633\u062a\u062e\u062f\u0645 \u0627\u0644\u0628\u0635\u0645\u0629 \u0623\u0648 \u0648\u0633\u064a\u0644\u0629 \u0627\u0644\u062a\u062d\u0642\u0642 \u0627\u0644\u062d\u064a\u0648\u064a \u0627\u0644\u0645\u0633\u062c\u0644\u0629 \u0639\u0644\u0649 \u0627\u0644\u0647\u0627\u062a\u0641"

    .line 172
    invoke-virtual {v0, v1}, Landroid/hardware/biometrics/BiometricPrompt$Builder;->setDescription(Ljava/lang/CharSequence;)Landroid/hardware/biometrics/BiometricPrompt$Builder;

    move-result-object v0

    const-string v1, "\u0627\u0633\u062a\u062e\u062f\u0627\u0645 \u0627\u0644\u0631\u0642\u0645 \u0627\u0644\u0633\u0631\u064a"

    .line 173
    invoke-virtual {p0}, Lcom/mostafabudget/expat/MainActivity;->getMainExecutor()Ljava/util/concurrent/Executor;

    move-result-object v3

    new-instance v4, Lcom/mostafabudget/expat/MainActivity$$ExternalSyntheticLambda6;

    invoke-direct {v4, p0}, Lcom/mostafabudget/expat/MainActivity$$ExternalSyntheticLambda6;-><init>(Lcom/mostafabudget/expat/MainActivity;)V

    invoke-virtual {v0, v1, v3, v4}, Landroid/hardware/biometrics/BiometricPrompt$Builder;->setNegativeButton(Ljava/lang/CharSequence;Ljava/util/concurrent/Executor;Landroid/content/DialogInterface$OnClickListener;)Landroid/hardware/biometrics/BiometricPrompt$Builder;

    move-result-object v0

    .line 175
    invoke-virtual {v0}, Landroid/hardware/biometrics/BiometricPrompt$Builder;->build()Landroid/hardware/biometrics/BiometricPrompt;

    move-result-object v0

    .line 176
    .local v0, "prompt":Landroid/hardware/biometrics/BiometricPrompt;
    new-instance v1, Landroid/os/CancellationSignal;

    invoke-direct {v1}, Landroid/os/CancellationSignal;-><init>()V

    .line 177
    .local v1, "signal":Landroid/os/CancellationSignal;
    invoke-virtual {p0}, Lcom/mostafabudget/expat/MainActivity;->getMainExecutor()Ljava/util/concurrent/Executor;

    move-result-object v3

    .line 178
    .local v3, "executor":Ljava/util/concurrent/Executor;
    new-instance v4, Lcom/mostafabudget/expat/MainActivity$1;

    invoke-direct {v4, p0}, Lcom/mostafabudget/expat/MainActivity$1;-><init>(Lcom/mostafabudget/expat/MainActivity;)V

    invoke-virtual {v0, v1, v3, v4}, Landroid/hardware/biometrics/BiometricPrompt;->authenticate(Landroid/os/CancellationSignal;Ljava/util/concurrent/Executor;Landroid/hardware/biometrics/BiometricPrompt$AuthenticationCallback;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 198
    .end local v0    # "prompt":Landroid/hardware/biometrics/BiometricPrompt;
    .end local v1    # "signal":Landroid/os/CancellationSignal;
    .end local v3    # "executor":Ljava/util/concurrent/Executor;
    goto :goto_0

    .line 196
    :catch_0
    move-exception v0

    .line 197
    .local v0, "error":Ljava/lang/Exception;
    invoke-direct {p0, v2}, Lcom/mostafabudget/expat/MainActivity;->callJavascript(Ljava/lang/String;)V

    .line 199
    .end local v0    # "error":Ljava/lang/Exception;
    :goto_0
    return-void
.end method


# virtual methods
.method protected onActivityResult(IILandroid/content/Intent;)V
    .locals 3
    .param p1, "requestCode"    # I
    .param p2, "resultCode"    # I
    .param p3, "data"    # Landroid/content/Intent;

    .line 306
    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onActivityResult(IILandroid/content/Intent;)V

    .line 307
    const/16 v0, 0x1008

    if-ne p1, v0, :cond_1

    const/4 v0, -0x1

    if-ne p2, v0, :cond_1

    if-eqz p3, :cond_1

    invoke-virtual {p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v0

    if-nez v0, :cond_0

    goto :goto_0

    .line 308
    :cond_0
    invoke-virtual {p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v0

    .line 309
    .local v0, "uri":Landroid/net/Uri;
    new-instance v1, Ljava/lang/Thread;

    new-instance v2, Lcom/mostafabudget/expat/MainActivity$$ExternalSyntheticLambda3;

    invoke-direct {v2, p0, v0}, Lcom/mostafabudget/expat/MainActivity$$ExternalSyntheticLambda3;-><init>(Lcom/mostafabudget/expat/MainActivity;Landroid/net/Uri;)V

    invoke-direct {v1, v2}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 320
    invoke-virtual {v1}, Ljava/lang/Thread;->start()V

    .line 321
    return-void

    .line 307
    .end local v0    # "uri":Landroid/net/Uri;
    :cond_1
    :goto_0
    return-void
.end method

.method public onBackPressed()V
    .locals 1

    .line 344
    iget-object v0, p0, Lcom/mostafabudget/expat/MainActivity;->webView:Landroid/webkit/WebView;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/webkit/WebView;->canGoBack()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/mostafabudget/expat/MainActivity;->webView:Landroid/webkit/WebView;

    invoke-virtual {v0}, Landroid/webkit/WebView;->goBack()V

    goto :goto_0

    :cond_0
    invoke-super {p0}, Landroid/app/Activity;->onBackPressed()V

    .line 345
    :goto_0
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 5
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 52
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 53
    invoke-virtual {p0}, Lcom/mostafabudget/expat/MainActivity;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/16 v1, 0xf5

    const/16 v2, 0xff

    const/16 v3, 0xee

    invoke-static {v3, v1, v2}, Landroid/graphics/Color;->rgb(III)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/view/Window;->setStatusBarColor(I)V

    .line 54
    invoke-virtual {p0}, Lcom/mostafabudget/expat/MainActivity;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/16 v1, 0xf6

    const/16 v2, 0xfa

    const/16 v3, 0xf3

    invoke-static {v3, v1, v2}, Landroid/graphics/Color;->rgb(III)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/view/Window;->setNavigationBarColor(I)V

    .line 55
    invoke-direct {p0}, Lcom/mostafabudget/expat/MainActivity;->createNotificationChannel()V

    .line 57
    new-instance v0, Landroid/webkit/WebView;

    invoke-direct {v0, p0}, Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcom/mostafabudget/expat/MainActivity;->webView:Landroid/webkit/WebView;

    .line 58
    invoke-virtual {v0}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v0

    .line 59
    .local v0, "settings":Landroid/webkit/WebSettings;
    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setJavaScriptEnabled(Z)V

    .line 60
    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setDomStorageEnabled(Z)V

    .line 61
    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setDatabaseEnabled(Z)V

    .line 62
    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setAllowFileAccess(Z)V

    .line 63
    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setAllowContentAccess(Z)V

    .line 64
    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setBuiltInZoomControls(Z)V

    .line 65
    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setDisplayZoomControls(Z)V

    .line 66
    const/16 v1, 0x64

    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setTextZoom(I)V

    .line 67
    iget-object v1, p0, Lcom/mostafabudget/expat/MainActivity;->webView:Landroid/webkit/WebView;

    new-instance v2, Landroid/webkit/WebViewClient;

    invoke-direct {v2}, Landroid/webkit/WebViewClient;-><init>()V

    invoke-virtual {v1, v2}, Landroid/webkit/WebView;->setWebViewClient(Landroid/webkit/WebViewClient;)V

    .line 68
    iget-object v1, p0, Lcom/mostafabudget/expat/MainActivity;->webView:Landroid/webkit/WebView;

    new-instance v2, Landroid/webkit/WebChromeClient;

    invoke-direct {v2}, Landroid/webkit/WebChromeClient;-><init>()V

    invoke-virtual {v1, v2}, Landroid/webkit/WebView;->setWebChromeClient(Landroid/webkit/WebChromeClient;)V

    .line 69
    iget-object v1, p0, Lcom/mostafabudget/expat/MainActivity;->webView:Landroid/webkit/WebView;

    new-instance v2, Lcom/mostafabudget/expat/MainActivity$AndroidBridge;

    const/4 v3, 0x0

    invoke-direct {v2, p0, v3}, Lcom/mostafabudget/expat/MainActivity$AndroidBridge;-><init>(Lcom/mostafabudget/expat/MainActivity;Lcom/mostafabudget/expat/MainActivity$AndroidBridge-IA;)V

    const-string v3, "Android"

    invoke-virtual {v1, v2, v3}, Landroid/webkit/WebView;->addJavascriptInterface(Ljava/lang/Object;Ljava/lang/String;)V

    .line 70
    iget-object v1, p0, Lcom/mostafabudget/expat/MainActivity;->webView:Landroid/webkit/WebView;

    const-string v2, "file:///android_asset/index.html"

    invoke-virtual {v1, v2}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V

    .line 71
    iget-object v1, p0, Lcom/mostafabudget/expat/MainActivity;->webView:Landroid/webkit/WebView;

    invoke-virtual {p0, v1}, Lcom/mostafabudget/expat/MainActivity;->setContentView(Landroid/view/View;)V

    .line 73
    iget-object v1, p0, Lcom/mostafabudget/expat/MainActivity;->webView:Landroid/webkit/WebView;

    new-instance v2, Lcom/mostafabudget/expat/MainActivity$$ExternalSyntheticLambda2;

    invoke-direct {v2, p0}, Lcom/mostafabudget/expat/MainActivity$$ExternalSyntheticLambda2;-><init>(Lcom/mostafabudget/expat/MainActivity;)V

    const-wide/16 v3, 0x384

    invoke-virtual {v1, v2, v3, v4}, Landroid/webkit/WebView;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 74
    return-void
.end method

.method public onRequestPermissionsResult(I[Ljava/lang/String;[I)V
    .locals 4
    .param p1, "requestCode"    # I
    .param p2, "permissions"    # [Ljava/lang/String;
    .param p3, "results"    # [I

    .line 325
    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onRequestPermissionsResult(I[Ljava/lang/String;[I)V

    .line 326
    const/16 v0, 0x1006

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-ne p1, v0, :cond_1

    .line 327
    array-length v0, p3

    const/4 v3, 0x0

    if-lez v0, :cond_0

    aget v0, p3, v1

    if-nez v0, :cond_0

    iget-object v0, p0, Lcom/mostafabudget/expat/MainActivity;->pendingPdfBytes:[B

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcom/mostafabudget/expat/MainActivity;->pendingPdfName:Ljava/lang/String;

    if-eqz v0, :cond_0

    .line 329
    iget-object v0, p0, Lcom/mostafabudget/expat/MainActivity;->pendingPdfBytes:[B

    .local v0, "bytes":[B
    iget-object v1, p0, Lcom/mostafabudget/expat/MainActivity;->pendingPdfName:Ljava/lang/String;

    .line 330
    .local v1, "name":Ljava/lang/String;
    iput-object v3, p0, Lcom/mostafabudget/expat/MainActivity;->pendingPdfBytes:[B

    iput-object v3, p0, Lcom/mostafabudget/expat/MainActivity;->pendingPdfName:Ljava/lang/String;

    .line 331
    new-instance v2, Ljava/lang/Thread;

    new-instance v3, Lcom/mostafabudget/expat/MainActivity$$ExternalSyntheticLambda4;

    invoke-direct {v3, p0, v1, v0}, Lcom/mostafabudget/expat/MainActivity$$ExternalSyntheticLambda4;-><init>(Lcom/mostafabudget/expat/MainActivity;Ljava/lang/String;[B)V

    invoke-direct {v2, v3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v2}, Ljava/lang/Thread;->start()V

    .line 332
    .end local v0    # "bytes":[B
    .end local v1    # "name":Ljava/lang/String;
    goto :goto_0

    .line 333
    :cond_0
    iput-object v3, p0, Lcom/mostafabudget/expat/MainActivity;->pendingPdfBytes:[B

    iput-object v3, p0, Lcom/mostafabudget/expat/MainActivity;->pendingPdfName:Ljava/lang/String;

    .line 334
    const-string v0, "\u064a\u0644\u0632\u0645 \u0627\u0644\u0633\u0645\u0627\u062d \u0628\u0627\u0644\u0648\u0635\u0648\u0644 \u0644\u0644\u062a\u0646\u0632\u064a\u0644\u0627\u062a \u0644\u062d\u0641\u0638 \u0627\u0644\u062a\u0642\u0631\u064a\u0631"

    invoke-static {p0, v0, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    goto :goto_0

    .line 336
    :cond_1
    const/16 v0, 0x1007

    if-ne p1, v0, :cond_2

    array-length v0, p3

    if-lez v0, :cond_2

    aget v0, p3, v1

    if-eqz v0, :cond_2

    .line 338
    const-string v0, "\u0644\u0646 \u062a\u0638\u0647\u0631 \u0627\u0644\u062a\u0630\u0643\u064a\u0631\u0627\u062a \u0628\u062f\u0648\u0646 \u0627\u0644\u0633\u0645\u0627\u062d \u0628\u0627\u0644\u0625\u0634\u0639\u0627\u0631\u0627\u062a"

    invoke-static {p0, v0, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 340
    :cond_2
    :goto_0
    return-void
.end method
