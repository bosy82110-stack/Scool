.class public final synthetic Lcom/mostafabudget/expat/MainActivity$AndroidBridge$$ExternalSyntheticLambda4;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/mostafabudget/expat/MainActivity$AndroidBridge;


# direct methods
.method public synthetic constructor <init>(Lcom/mostafabudget/expat/MainActivity$AndroidBridge;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/mostafabudget/expat/MainActivity$AndroidBridge$$ExternalSyntheticLambda4;->f$0:Lcom/mostafabudget/expat/MainActivity$AndroidBridge;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    iget-object v0, p0, Lcom/mostafabudget/expat/MainActivity$AndroidBridge$$ExternalSyntheticLambda4;->f$0:Lcom/mostafabudget/expat/MainActivity$AndroidBridge;

    invoke-static {v0}, Lcom/mostafabudget/expat/MainActivity$AndroidBridge;->$r8$lambda$5n75QEgObNd_ouy9nsu0-bmkOwU(Lcom/mostafabudget/expat/MainActivity$AndroidBridge;)V

    return-void
.end method
