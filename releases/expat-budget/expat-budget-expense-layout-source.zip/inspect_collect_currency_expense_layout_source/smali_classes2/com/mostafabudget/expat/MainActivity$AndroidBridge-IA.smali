.class public final synthetic Lcom/mostafabudget/expat/MainActivity$AndroidBridge-IA;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"
