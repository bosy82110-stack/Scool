.class public final synthetic Lcom/mostafabudget/expat/MainActivity$AndroidBridge$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/mostafabudget/expat/MainActivity$AndroidBridge;

.field public final synthetic f$1:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lcom/mostafabudget/expat/MainActivity$AndroidBridge;Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/mostafabudget/expat/MainActivity$AndroidBridge$$ExternalSyntheticLambda2;->f$0:Lcom/mostafabudget/expat/MainActivity$AndroidBridge;

    iput-object p2, p0, Lcom/mostafabudget/expat/MainActivity$AndroidBridge$$ExternalSyntheticLambda2;->f$1:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    iget-object v0, p0, Lcom/mostafabudget/expat/MainActivity$AndroidBridge$$ExternalSyntheticLambda2;->f$0:Lcom/mostafabudget/expat/MainActivity$AndroidBridge;

    iget-object v1, p0, Lcom/mostafabudget/expat/MainActivity$AndroidBridge$$ExternalSyntheticLambda2;->f$1:Ljava/lang/String;

    invoke-static {v0, v1}, Lcom/mostafabudget/expat/MainActivity$AndroidBridge;->$r8$lambda$pbNrAr389c8PNZBjPbzeGCrOXBs(Lcom/mostafabudget/expat/MainActivity$AndroidBridge;Ljava/lang/String;)V

    return-void
.end method
